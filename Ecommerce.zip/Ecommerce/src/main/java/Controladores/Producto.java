/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controladores;

import Modelos.ProductoDB;

/**
 *
 * @author sandracano
 */
public class Producto implements ProductoDB {
    
    
    public void Crear(){
        
    }
    
    public void Leer(){
        
    }
    
    public void Actualizar(){
        
    }
    
    public void Eliminar(){
        
    }
    
}
