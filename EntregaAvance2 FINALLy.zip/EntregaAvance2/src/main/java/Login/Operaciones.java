/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Login;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author 56977
 */
class Operaciones {
    public Scanner Entrada=new Scanner(System.in);

    public Operaciones() {
    }
    
    public int Menu(){
       
       System.out.println("1-Crear Trabajadores");
       System.out.println("2-Listar Trabajadores");
       System.out.println("3-Eliminar Trabajadores");
       System.out.println("4-Actualizar o Modificar Trabajadores");
       System.out.println("5-Agregar chofer");
       System.out.println("6-Imprimir chofer");  
       System.out.println("7-Iniciar Sesión");  
       System.out.println("Digite la opcion:");
       
       int opcion=Entrada.nextInt();
       
       return opcion;
   }

    public void Mensaje(String texto){
        System.out.println(texto);
    }
    
    public String guardarRut(){
        String rut=Entrada.next();
        return rut;
    }
    
    public String guardarNombre(){
        String nombre=Entrada.next();
        return nombre;
    }
    
    public int guardarIdChofer(){
        int IdChofer=Entrada.nextInt();
        return IdChofer;
    }
    
    
    
}
