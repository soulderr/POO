/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Login;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author 56977
 */
public class Chofer extends Trabajador {
    
    private int IdChofer;  //id del trabajador en la empresa
    private Date FechaInicio;  //Inicio trabajo(año,mes,dia,hora,minuto,seg)
    private Date FechaTermino; //Termino trabajo
    
    private ArrayList<Chofer> LChofer=new ArrayList<Chofer>();
    public Operaciones operaciones=new Operaciones();
    
    //Constructor

    public Chofer(int IdChofer, Date FechaInicio, Date FechaTermino) {
        this.IdChofer = IdChofer;
        this.FechaInicio = FechaInicio;
        this.FechaTermino = FechaTermino;
    }

    public Chofer(int IdChofer, Date FechaInicio, Date FechaTermino, String Rut, String Nombre) {
        super(Rut, Nombre);
        this.IdChofer = IdChofer;
        this.FechaInicio = FechaInicio;
        this.FechaTermino = FechaTermino;
    }

    

    

    

    //Accesores (Get)

    public int getIdChofer() {
        return IdChofer;
    }
    
    public Date getFechaInicio() {
        return FechaInicio;
    }

    public Date getFechaTermino() {
        return FechaTermino;
    }
    
    //Mutadores (Set)

    public void setIdChofer(int IdChofer) {
        this.IdChofer = IdChofer;
    }

    public void setFechaInicio(Date FechaInicio) {
        this.FechaInicio = FechaInicio;
    }

    public void setFechaTermino(Date FechaTermino) {
        this.FechaTermino = FechaTermino;
    }  
    
    

    boolean isActivo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
