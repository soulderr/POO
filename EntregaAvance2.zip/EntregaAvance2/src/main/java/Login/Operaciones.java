/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Login;

import java.util.Scanner;

/**
 *
 * @author 56977
 */
class Operaciones {
    public Scanner Entrada=new Scanner(System.in);

    public Operaciones() {
    }
    
    public int Menu(){
       
       Mensaje("1-Crear Choferes");
       Mensaje("2-Listar Choferes");
       Mensaje("3-Actualizar Choferes");
       Mensaje("4-Eliminar Choferes");
       Mensaje("5-Salir");       
       Mensaje("Digite la opcion");
       
       int opcion=Entrada.nextInt();
       
       return opcion;
   }

    public void Mensaje(String texto){
        System.out.println(texto);
    }
}
