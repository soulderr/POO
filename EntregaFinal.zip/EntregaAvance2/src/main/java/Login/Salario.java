/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Login;

/**
 *
 * @author 56977
 */
public abstract class Salario {
    private int sueldo;
    
    public Salario(int sueldo){
	this.sueldo=sueldo;
    }

    public abstract void calcularSueldo();
    public abstract void mostrarResultado();
}
