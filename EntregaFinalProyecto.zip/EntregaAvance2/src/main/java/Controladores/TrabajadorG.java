/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controladores;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

import Login.TrabajadorDB;
import Login.Trabajador;
import java.util.ArrayList;
/**
 *
 * @author 56977
 */
public class TrabajadorG implements TrabajadorDB {

    
    public String query;
    
    public ArrayList<Trabajador> Leer(Connection link){
        
        Trabajador trabajador=new Trabajador();
        try{
            Statement s = link.createStatement();
            query="select * from Clientes";
            ResultSet rs=s.executeQuery(query);
            while (rs.next()){
                
               trabajador.setRut(rs.getString("rut"));
               trabajador.setNombre(rs.getString("nombre"));
               
               
               ListaTrabajador.add(trabajador);
                
            }
            
            return ListaTrabajador;
        }catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public void Actualizar(){
        
    }
    
    public void Eliminar(){
        
    }
    
    public boolean Crear(Connection link, Trabajador trabajador){
        
        try{
            Statement s = link.createStatement();
            query="insert into Trabajador(rut,nombre)values('"+trabajador.getRut()+"','"+trabajador.getNombre()+"')";
            s.executeUpdate(query);
            return true;
            
        }catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
        
    }
    
    public Trabajador Buscar(Connection link, String rut){
        Trabajador trabajador=new Trabajador();
        try {
            Statement s = link.createStatement();
            query="select * from Clientes where rut='"+rut+"'";
            ResultSet rs=s.executeQuery(query);
            
                   
   
            while (rs.next()){
               trabajador.setRut(rs.getString("rut"));
               trabajador.setNombre(rs.getString("nombre"));
              
                
            }
            return trabajador;
  
            
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
