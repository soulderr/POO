/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Login;

/**
 *
 * @author 56977
 */
public class Calculo extends Salario {
    private double valorHora, iva, salario;
    private int numeroHoras;
    
    public Calculo(int sueldo, int numeroHoras, double valorHora, double iva, double salario) {
        super(sueldo);
        this.numeroHoras=numeroHoras;
        this.valorHora=valorHora;
        this.iva=iva;
	this.salario=salario;
    }
    public void calcularSueldo(){
        salario = (numeroHoras*valorHora)-((numeroHoras*valorHora)*(iva/100));
    }
    public void mostrarResultado(){
        System.out.print("\nSALARIO = " + salario);
    }

    
}
