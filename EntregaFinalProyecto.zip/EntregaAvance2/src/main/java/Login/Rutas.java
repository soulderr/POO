/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Login;

/**
 *
 * @author 56977
 */
public class Rutas {
    private int NumeroIdentificador;
    private String TramoInicio;
    private String TramoFinal;

    public Rutas() {
    }

    public Rutas(int NumeroIdentificador, String TramoInicio, String TramoFinal) {
        this.NumeroIdentificador = NumeroIdentificador;
        this.TramoInicio = TramoInicio;
        this.TramoFinal = TramoFinal;
    }

    public int getNumeroIdentificador() {
        return NumeroIdentificador;
    }

    public String getTramoInicio() {
        return TramoInicio;
    }

    public String getTramoFinal() {
        return TramoFinal;
    }

    public void setNumeroIdentificador(int NumeroIdentificador) {
        this.NumeroIdentificador = NumeroIdentificador;
    }

    public void setTramoInicio(String TramoInicio) {
        this.TramoInicio = TramoInicio;
    }

    public void setTramoFinal(String TramoFinal) {
        this.TramoFinal = TramoFinal;
    }
}
