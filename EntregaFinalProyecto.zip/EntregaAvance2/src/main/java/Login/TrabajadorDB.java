/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Login;

import java.sql.Connection;
import java.util.ArrayList;

/**
 *
 * @author 56977
 */
public interface TrabajadorDB {
    ArrayList<Trabajador>ListaTrabajador=new ArrayList<Trabajador>();
    public boolean Crear(Connection link, Trabajador trabajador);
    public void Actualizar();
    public void Eliminar();
    public ArrayList<Trabajador> Leer(Connection link);
    public Trabajador Buscar(Connection link, String rut);
}
