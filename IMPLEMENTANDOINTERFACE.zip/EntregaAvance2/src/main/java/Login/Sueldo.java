/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Login;

/**
 *
 * @author 56977
 */
public interface Sueldo {
    public static final int SUELDOPORHORA=15000;
    public double CalcularSueldo();
}
