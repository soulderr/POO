/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Login;

import Login.Reporte.CsvValidationException;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;



/**
 *
 * @author 56977
 */
class Reporte {
    private String Ruta;
    
    private ArrayList<Trabajador> LTrabajador=new ArrayList<Trabajador>();

    public Reporte(String Ruta) {
        this.Ruta = Ruta;
    }
    
    public void Leer() throws CsvValidationException{
        File file = new File(this.Ruta);
        try {
            FileReader inputfile = new FileReader(file);
            CSVReader reader = new CSVReader(inputfile);
        
            String[] nextRecord;
            
            // we are going to read data line by line
            int i=0;
            while ((nextRecord = reader.readNext()) != null) {
                
                //System.out.println(nextRecord[4]);
                if(i>0)LTrabajador.add(new Trabajador(nextRecord[0],nextRecord[1]));
                  
                
                for (String cell : nextRecord) {
                    
                    System.out.print(cell + "\t");
                }
                i++;
                System.out.println();
            }
            
        
        }catch (IOException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
        }
    }
    
    public void Escribir(String [] header, ArrayList <Trabajador> Datos){
        File file = new File(this.Ruta);
        try {
        // create FileWriter object with file as parameter
        FileWriter outputfile = new FileWriter(file);
  
        // create CSVWriter object filewriter object as parameter
        
        CSVWriter writer = new CSVWriter(outputfile);
  
        // adding header to csv
        //String[] header = { "Name", "Class", "Marks" };
        writer.writeNext(header);
        
        
        // add data to csv
        
        
        for(int i=0;i<Datos.size();i++){
            
            String[] data = {Datos.get(i).getRut(),Datos.get(i).getNombre()};
            writer.writeNext(data);
        }
        
        
  
        // closing writer connection
        writer.close();
    }
    catch (IOException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    }
        
    }

    
  
}

    

