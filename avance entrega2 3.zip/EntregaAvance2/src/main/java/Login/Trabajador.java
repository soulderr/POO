/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Login;

import static Login.Login.reporte;
import java.util.ArrayList;
import java.util.Date;
import static org.apache.commons.collections.CollectionUtils.index;

/**
 *
 * @author 56977
 */
public class Trabajador {
    private String Rut;
    private String Nombre;
    private ArrayList<Trabajador> LTrabajador=new ArrayList<Trabajador>();
    public Operaciones operaciones=new Operaciones();
    
    public Trabajador() {
    }

    public Trabajador(String Rut, String Nombre) {
        this.Rut = Rut;
        this.Nombre = Nombre;
    }

    public String getRut() {
        return Rut;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setRut(String Rut) {
        this.Rut = Rut;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }
    
    public void CrearDatos(){
        String Rut;
        String Nombre;
        
        
        System.out.println("Escriba el rut");
        Rut=operaciones.guardarRut();
        System.out.println("Escriba el nombre");
        Nombre=operaciones.guardarNombre();
        
        LTrabajador.add(new Trabajador(Rut,Nombre));
    }
    
    public void ImprimirDatos(){
        System.out.println("El nombre y rut son: ");
        for(int i=0;i<LTrabajador.size();i++){
            System.out.println("Nombre: "+LTrabajador.get(i).Nombre+"y rut: "+LTrabajador.get(i).Rut);
        }
       
    }
    
   public void modificar(){
       System.out.println("Escriba el rut que desea eliminar");
       Rut=operaciones.guardarRut();
       
       for(int i=0;i<LTrabajador.size();i++){
           if(LTrabajador.get(i).Rut.equals(Rut)){
               LTrabajador.remove(i);
           }
       }
   }
}
