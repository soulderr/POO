/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practicainterfaz;

import java.util.ArrayList;

/**
 *
 * @author Estudiante
 */
public class Carrera {
    private int Identificador;
    private String Nombre;
    private String AreaSaber;
    private ArrayList<Carrera>Carreras=new ArrayList<Carrera>();

    public Carrera() {
    }

    public Carrera(int Identificador, String Nombre, String AreaSaber) {
        this.Identificador = Identificador;
        this.Nombre = Nombre;
        this.AreaSaber = AreaSaber;
    }

    public int getIdentificador() {
        return Identificador;
    }

    public String getNombre() {
        return Nombre;
    }

    public String getAreaSaber() {
        return AreaSaber;
    }

    public void setIdentificador(int Identificador) {
        this.Identificador = Identificador;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public void setAreaSaber(String AreaSaber) {
        this.AreaSaber = AreaSaber;
    }
    
    public boolean agregarEstudiante(Estudiante estudiante){
        Estudiante objeto=new Estudiante ();
        if(objeto.agregarEstudiante(estudiante)){
            return true;
        }
        return false;
    }
    
    public Estudiante obtenerEstudiante(int rol){
        Estudiante objeto=new Estudiante ();
        if(objeto.obtenerEstudiante(rol)!= null){
            objeto=obtenerEstudiante(rol);
            return objeto;
        }
        return null;
    }   
    
    public boolean buscarCarrera(Carrera objeto){
        
        for(int i=0;i<Carreras.size();i++){
            if(Carreras.get(i).Identificador==objeto.Identificador){
                return false;
            }
        }
        Carreras.add(objeto);
        return true;
    }
    
      public boolean existeCarrera(int identificador){
        
        for(int i=0;i<Carreras.size();i++){
            if(Carreras.get(i).Identificador==identificador){
                return true;
            }
        }
        return false;
    }
    
    