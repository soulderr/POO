/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practicainterfaz;

import java.util.ArrayList;

/**
 *
 * @author Estudiante
 */
public class Estudiante {
    private int rut;
    private String nombre;
    private ArrayList<Estudiante>Estudiantes=new ArrayList<Estudiante>();

    public Estudiante() {
    }

    public Estudiante(int rut, String nombre) {
        this.rut = rut;
        this.nombre = nombre;
    }

    public int getRut() {
        return rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setRut(int rut) {
        this.rut = rut;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public boolean agregarEstudiante(Estudiante objeto){
        
        for(int i=0;i<Estudiantes.size();i++){
            if(Estudiantes.get(i).rut==objeto.rut){
                return false;
            }   
        }
        Estudiantes.add(objeto);
        return true;
    }
    
    public Estudiante obtenerEstudiante(int rol){
       
        for(int i=0;i<Estudiantes.size();i++){
            if(Estudiantes.get(i).rut==rol){
                return Estudiantes.get(i);
            }
        }
        return null;
    }
    
}  

