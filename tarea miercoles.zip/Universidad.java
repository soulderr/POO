/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practicainterfaz;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Estudiante
 */
public class Universidad {
    
    ArrayList<Carrera>Carreras=new ArrayList<Carrera>();
    HashMap<ICarrera,Estudiante>Estudiantes=new HashMap<ICarrera,Estududiante>();
    
    public boolean  agregarCarrera(Carrera carrera){
        Carrera objeto=new Carrera ();
        if(objeto.buscarCarrera(carrera)){
            return true;
        }
        return false;
    }
    
    public boolean  agregarEstudiante(int ICarrera,Estudiante estudiante){
        Carrera objeto=new Carrera();
        Estudiante objeto1=new Estudiante();
        if(objeto.existeCarrera(ICarrera)==true){
            objeto1.agregarEstudiante(estudiante);
            return true;
        }
        return false;
    }
    
    public Estudiante  obtenerEstudiante(int rut){
        Estudiante objeto=new Estudiante();
        if(objeto.obtenerEstudiante(rut)!=null){
            objeto=objeto.obtenerEstudiante(rut);
            return objeto;
        }
        return null;
    }
}
